             function bowChange(num) {  //changes images for bowtie gallery
                 var bow = 'bowtie' + num + '.png';
                 document.getElementById("mainImg").src = bow;
             }

             function tieChange(num) {  //changes images for bnecktie gallery
                 var tie = 'necktie' + num + '.png';
                 document.getElementById("mainImg").src = tie;
             }

             function openNav() {   //opens sidenav
                 document.getElementById("Sidenav").style.width = "40%";
             }

             function closeNav() {  //closes sidenav
                 document.getElementById("Sidenav").style.width = "0";
             }
